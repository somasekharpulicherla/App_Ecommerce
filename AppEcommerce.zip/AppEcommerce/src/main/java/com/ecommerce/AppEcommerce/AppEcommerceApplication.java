package com.ecommerce.AppEcommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppEcommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppEcommerceApplication.class, args);
	}

}
