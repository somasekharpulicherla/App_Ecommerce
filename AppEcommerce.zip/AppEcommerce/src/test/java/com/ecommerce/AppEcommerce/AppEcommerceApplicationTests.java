package com.ecommerce.AppEcommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppEcommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
